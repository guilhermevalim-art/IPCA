# Controle de PJ - IPCA

App web com login (administrador e usuário padrão), dados compartilhados entre todos os usuários e atualização automática.

## Publicar de graça no Vercel
1. Envie estes arquivos para o repositório do GitHub (substitua os antigos).
2. No Vercel, abra o projeto > aba **Storage** > **Create Database** > escolha **Upstash Redis** (plano Free) > conecte ao projeto. Isso cria as variáveis de ambiente sozinho.
3. Vá em **Deployments** > no último deploy, menu "..." > **Redeploy**.
4. Abra o link. No primeiro acesso, crie o administrador (a base atual de colaboradores é carregada nesse momento).

## Rodar no computador
Defina KV_REST_API_URL e KV_REST_API_TOKEN (de um banco Upstash) e rode `npm install` e `npm start`.

## Estrutura
- `server.js`: API (Express). Senhas com scrypt, sessão em cookie assinado, dados no Upstash Redis.
- `public/index.html`: o aplicativo.
- `seed.json`: base inicial de colaboradores.
