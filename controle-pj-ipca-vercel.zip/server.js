const express=require('express'),path=require('path'),crypto=require('crypto');
const URL_=process.env.KV_REST_API_URL||process.env.UPSTASH_REDIS_REST_URL,TOK=process.env.KV_REST_API_TOKEN||process.env.UPSTASH_REDIS_REST_TOKEN;
async function raw(p,body){if(!URL_||!TOK)throw Object.assign(new Error('Banco de dados não configurado. Crie o banco (Upstash Redis) na aba Storage do Vercel e faça um novo deploy.'),{st:503});
const r=await fetch(URL_+p,{method:'POST',headers:{Authorization:'Bearer '+TOK},body:JSON.stringify(body)}),j=await r.json();if(!r.ok)throw new Error(j.error||'Erro no banco');return j}
const R=async c=>{const j=await raw('',c);if(j.error)throw new Error(j.error);return j.result};
const P=async cs=>(await raw('/pipeline',cs)).map(x=>{if(x.error)throw new Error(x.error);return x.result});
let SEC=process.env.SESSION_SECRET;
async function secret(){if(SEC)return SEC;let s=await R(['GET','secret']);if(!s){await R(['SET','secret',crypto.randomBytes(32).toString('hex'),'NX']);s=await R(['GET','secret'])}return SEC=s}
const hs=(p,s)=>crypto.scryptSync(p,s,32).toString('hex');
const sig=async b=>crypto.createHmac('sha256',await secret()).update(b).digest('base64url');
const cookie=async(q,res,u)=>{const b=Buffer.from(u+'|'+(Date.now()+12*36e5)).toString('base64url');res.setHeader('Set-Cookie',`t=${b}.${await sig(b)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=43200${q.secure?'; Secure':''}`)};
async function uid(r){const c=(r.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('t='));if(!c)return;const[b,g]=c.slice(2).split('.');if(!g||(await sig(b))!==g)return;const[u,e]=Buffer.from(b,'base64url').toString().split('|');if(+e<Date.now())return;return u}
async function who(r){const u=await uid(r);if(!u)return;const x=await R(['HGET','users',u]);if(!x)return;const o=JSON.parse(x);return o.ativo?o:undefined}
const pub=x=>({u:x.u,name:x.name,role:x.role,ativo:x.ativo,mustChange:!!x.mustChange});
const nz=s=>String(s||'').normalize('NFD').replace(/[̀-ͯ]/g,'').toLowerCase().replace(/[^a-z0-9 ]/g,' ').replace(/\s+/g,' ').trim();
const saveU=x=>R(['HSET','users',x.u,JSON.stringify(x)]),bump=()=>R(['INCR','ver']);
const app=express();app.set('trust proxy',1);app.use(express.json({limit:'1mb'}));
const w=f=>(q,s,n)=>Promise.resolve(f(q,s,n)).catch(e=>s.status(e.st||500).json({erro:e.message||'Erro interno'}));
const A=w(async(q,s,n)=>{q.me=await who(q);if(!q.me)return s.sendStatus(401);if(q.me.mustChange&&q.path!='/password'&&q.path!='/logout')return s.status(403).json({erro:'Crie sua nova senha primeiro.'});n()});
const AD=(q,s,n)=>q.me.role=='admin'?n():s.status(403).json({erro:'Somente administrador.'});
app.get('/api/me',w(async(q,s)=>{const m=await who(q),n=await R(['HLEN','users']);s.json({needSetup:!n,me:m?pub(m):null})}));
app.post('/api/setup',w(async(q,s)=>{const{u,name,p}=q.body||{};if(!/^[a-z0-9._-]{3,30}$/.test(u||'')||!name||String(p||'').length<4)return s.status(400).json({erro:'Dados inválidos.'});
if(await R(['HLEN','users']))return s.status(403).json({erro:'Já configurado.'});if(!(await R(['SETNX','setup_lock','1'])))return s.status(403).json({erro:'Configuração em andamento.'});
try{const salt=crypto.randomBytes(16).toString('hex'),x={u,name,role:'admin',salt,hash:hs(p,salt),ativo:true},sd=require('./seed.json'),L=sd.ps;
for(let i=0;i<L.length;i+=40){const c=['HSET','ps'];L.slice(i,i+40).forEach(z=>c.push(z.id,JSON.stringify(z)));await R(c)}
await P([['SET','ipca',JSON.stringify(sd.ipca||{})],['SET','log',JSON.stringify(sd.log||[])]]);await saveU(x);await bump();await cookie(q,s,u);s.json({me:pub(x)})}catch(e){await R(['DEL','setup_lock']);throw e}}));
app.post('/api/login',w(async(q,s)=>{const k='fl:'+q.ip,n=await R(['INCR',k]);if(n==1)await R(['EXPIRE',k,60]);if(n>8)return s.status(429).json({erro:'Muitas tentativas. Aguarde 1 minuto.'});
const{u,p}=q.body||{},r=await R(['HGET','users',String(u||'').toLowerCase()]),x=r&&JSON.parse(r);
if(!x||!x.ativo||hs(String(p||''),x.salt)!==x.hash)return s.status(401).json({erro:'Usuário ou senha inválidos.'});await R(['DEL',k]);await cookie(q,s,x.u);s.json({me:pub(x)})}));
app.post('/api/logout',(q,s)=>{s.setHeader('Set-Cookie','t=; Max-Age=0; Path=/');s.json({})});
app.get('/api/ver',w(async(q,s)=>{if(!(await uid(q)))return s.sendStatus(401);s.json({v:await R(['GET','ver'])})}));
app.use('/api',A);
app.post('/api/password',w(async(q,s)=>{const x=q.me,{a,n}=q.body||{};if(String(n||'').length<4)return s.status(400).json({erro:'A senha precisa ter ao menos 4 caracteres.'});
if(!x.mustChange&&hs(String(a||''),x.salt)!==x.hash)return s.status(400).json({erro:'Senha atual incorreta.'});
if(hs(n,x.salt)===x.hash)return s.status(400).json({erro:'Escolha uma senha diferente da atual/padrão.'});
x.salt=crypto.randomBytes(16).toString('hex');x.hash=hs(n,x.salt);x.mustChange=false;await saveU(x);s.json({me:pub(x)})}));
app.get('/api/data',w(async(q,s)=>{const[ps,ip,lg,v]=await P([['HVALS','ps'],['GET','ipca'],['GET','log'],['GET','ver']]);s.json({ps:ps.map(x=>JSON.parse(x)),ipca:JSON.parse(ip||'{}'),log:JSON.parse(lg||'[]'),v})}));
app.put('/api/ps/:id',w(async(q,s)=>{if(!q.body||q.body.id!=q.params.id)return s.sendStatus(400);await P([['HSET','ps',q.params.id,JSON.stringify(q.body)],['INCR','ver']]);s.json({})}));
app.put('/api/ipca',w(async(q,s)=>{await P([['SET','ipca',JSON.stringify((q.body||{}).m||{})],['INCR','ver']]);s.json({})}));
app.put('/api/log',w(async(q,s)=>{await P([['SET','log',JSON.stringify((q.body||{}).l||[])],['INCR','ver']]);s.json({})}));
const allU=async()=>(await R(['HVALS','users'])).map(x=>JSON.parse(x));
app.get('/api/users',AD,w(async(q,s)=>s.json({users:(await allU()).map(pub)})));
app.post('/api/users',AD,w(async(q,s)=>{const{name,p,role}=q.body||{},wd=nz(name).split(' ').filter(Boolean);
if(wd.length<2)return s.status(400).json({erro:'Informe nome e sobrenome.'});if(String(p||'').length<4)return s.status(400).json({erro:'A senha padrão precisa ter ao menos 4 caracteres.'});
const b=(wd[0]+'.'+wd[wd.length-1]).slice(0,26),us=await allU();let u=b,i=2;while(us.some(y=>y.u==u))u=b+i++;
const salt=crypto.randomBytes(16).toString('hex');await saveU({u,name:String(name).trim().replace(/\s+/g,' '),role:role=='admin'?'admin':'user',salt,hash:hs(p,salt),ativo:true,mustChange:true});s.json({u})}));
const T=w(async(q,s,n)=>{const r=await R(['HGET','users',q.params.u]);if(!r)return s.sendStatus(404);q.t=JSON.parse(r);const us=await allU();q.lock=q.t.u==q.me.u||(q.t.role=='admin'&&q.t.ativo&&us.filter(y=>y.role=='admin'&&y.ativo).length<2);n()});
app.post('/api/users/:u/reset',AD,T,w(async(q,s)=>{const p=(q.body||{}).p;if(String(p||'').length<4)return s.status(400).json({erro:'A nova senha precisa ter ao menos 4 caracteres.'});q.t.salt=crypto.randomBytes(16).toString('hex');q.t.hash=hs(p,q.t.salt);q.t.mustChange=true;await saveU(q.t);s.json({})}));
app.post('/api/users/:u/toggle',AD,T,w(async(q,s)=>{if(q.lock)return s.status(400).json({erro:'Não é possível desativar este usuário.'});q.t.ativo=!q.t.ativo;await saveU(q.t);s.json({})}));
app.delete('/api/users/:u',AD,T,w(async(q,s)=>{if(q.lock)return s.status(400).json({erro:'Não é possível excluir este usuário.'});await R(['HDEL','users',q.t.u]);s.json({})}));
app.use(express.static(path.join(__dirname,'public')));
module.exports=app;
if(require.main===module)app.listen(process.env.PORT||3000,()=>console.log('Online na porta '+(process.env.PORT||3000)));
